package app;

import perpustakaan.*;

public class Main {
    public static void main(String[] args) {
        Buku nonFiksi = new NonFiksi("Madilog", "Tan Malaka", "Sejarah & Ilmu Pengetahuan");
        Buku fiksi = new Fiksi("Hainuwele: Sang Putri Kelapa", "Lilis Hu", "Dongeng");

        nonFiksi.displayInfo();
        fiksi.displayInfo();
        System.out.println();

        Anggota adit = new Anggota("Adit", "B057");
        Anggota yassa = new Anggota("Yassa", "B037");

        adit.displayInfo();
        yassa.displayInfo();
        System.out.println();

        adit.pinjamBuku("Madilog");
        yassa.pinjamBuku("Hainuwele: Sang Putri Kelapa", 7);
        System.out.println();

        adit.kembalikanBuku("Madilog");
        yassa.kembalikanBuku("Hainuwele: Sang Putri Kelapa");
    }
}